import { notFound } from "next/navigation"
import Link from "next/link"
import { Scale, Building2, Home, Heart, Shield, FileText, ArrowLeft, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

const servicesData = {
  "civil-litigation": {
    icon: Scale,
    title: "Civil Litigation",
    description: "Expert representation in civil matters with proven track record",
    fullDescription:
      "Our civil litigation practice encompasses a wide range of disputes including contract disputes, property disputes, tort claims, and commercial litigation. We provide strategic counsel and aggressive representation to protect your interests.",
    features: [
      "Contract Dispute Resolution",
      "Property and Land Disputes",
      "Tort Claims and Personal Injury",
      "Commercial Litigation",
      "Debt Recovery",
      "Injunction Applications",
    ],
    process: [
      "Initial Consultation and Case Assessment",
      "Legal Strategy Development",
      "Evidence Collection and Documentation",
      "Court Representation and Advocacy",
      "Settlement Negotiations",
      "Post-Judgment Enforcement",
    ],
  },
  "corporate-law": {
    icon: Building2,
    title: "Corporate Law",
    description: "Business legal services and corporate compliance solutions",
    fullDescription:
      "We provide comprehensive corporate legal services to businesses of all sizes, from startups to established corporations. Our expertise includes company formation, corporate governance, mergers and acquisitions, and regulatory compliance.",
    features: [
      "Company Formation and Registration",
      "Corporate Governance Advisory",
      "Mergers and Acquisitions",
      "Shareholder Agreements",
      "Regulatory Compliance",
      "Corporate Restructuring",
    ],
    process: [
      "Business Structure Consultation",
      "Legal Documentation Preparation",
      "Regulatory Filing and Compliance",
      "Ongoing Corporate Advisory",
      "Transaction Support",
      "Risk Management",
    ],
  },
  "property-law": {
    icon: Home,
    title: "Property Law",
    description: "Real estate transactions and property dispute resolution",
    fullDescription:
      "Our property law practice covers all aspects of real estate transactions, property disputes, and land matters. We ensure smooth property transfers and protect your property rights through expert legal guidance.",
    features: [
      "Property Purchase and Sale",
      "Title Verification and Due Diligence",
      "Property Dispute Resolution",
      "Lease and Rental Agreements",
      "Property Development Advisory",
      "Land Acquisition",
    ],
    process: [
      "Property Documentation Review",
      "Title Search and Verification",
      "Agreement Drafting and Negotiation",
      "Registration and Transfer",
      "Dispute Resolution",
      "Post-Transaction Support",
    ],
  },
  "family-law": {
    icon: Heart,
    title: "Family Law",
    description: "Sensitive family matters handled with care and expertise",
    fullDescription:
      "We understand that family matters require sensitivity and discretion. Our family law practice provides compassionate legal support for divorce, child custody, maintenance, and other family-related issues.",
    features: [
      "Divorce and Separation",
      "Child Custody and Visitation",
      "Maintenance and Alimony",
      "Guardianship Matters",
      "Adoption Proceedings",
      "Domestic Violence Protection",
    ],
    process: [
      "Confidential Consultation",
      "Case Strategy Development",
      "Mediation and Negotiation",
      "Court Representation",
      "Settlement Documentation",
      "Post-Decree Modifications",
    ],
  },
  "criminal-defense": {
    icon: Shield,
    title: "Criminal Defense",
    description: "Strong defense representation for criminal cases",
    fullDescription:
      "Our criminal defense team provides vigorous representation for individuals facing criminal charges. We protect your rights and work tirelessly to achieve the best possible outcome in your case.",
    features: [
      "Pre-Trial Investigation",
      "Bail Applications",
      "Trial Representation",
      "Appeals and Revisions",
      "White Collar Crime Defense",
      "Juvenile Defense",
    ],
    process: [
      "Immediate Legal Consultation",
      "Case Investigation and Analysis",
      "Defense Strategy Formulation",
      "Bail Application and Hearing",
      "Trial Preparation and Representation",
      "Post-Conviction Relief",
    ],
  },
  "contract-law": {
    icon: FileText,
    title: "Contract Law",
    description: "Contract drafting, review, and dispute resolution",
    fullDescription:
      "We provide comprehensive contract law services including drafting, reviewing, and negotiating contracts. Our expertise ensures your agreements are legally sound and protect your interests.",
    features: [
      "Contract Drafting and Review",
      "Contract Negotiation",
      "Breach of Contract Claims",
      "Contract Dispute Resolution",
      "Employment Contracts",
      "Commercial Agreements",
    ],
    process: [
      "Requirements Analysis",
      "Contract Drafting or Review",
      "Negotiation Support",
      "Contract Finalization",
      "Dispute Resolution",
      "Contract Management Advisory",
    ],
  },
}

export function generateStaticParams() {
  return Object.keys(servicesData).map((slug) => ({
    slug,
  }))
}

export default function ServicePage({ params }: { params: { slug: string } }) {
  const service = servicesData[params.slug as keyof typeof servicesData]

  if (!service) {
    notFound()
  }

  const Icon = service.icon

  return (
    <div className="min-h-screen">
      <Header />

      <main className="pt-24 pb-20">
        {/* Hero Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-12 bg-gradient-to-br from-primary/10 to-primary/5 animate-fade-in">
          <div className="container mx-auto">
            <Link
              href="/#services"
              className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Services
            </Link>
            <div className="flex items-start gap-6">
              <div className="w-16 h-16 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Icon className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h1 className="text-4xl sm:text-5xl font-bold mb-4">{service.title}</h1>
                <p className="text-xl text-muted-foreground">{service.description}</p>
              </div>
            </div>
          </div>
        </section>

        {/* Overview Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 animate-slide-up">
          <div className="container mx-auto max-w-4xl">
            <h2 className="text-3xl font-bold mb-6">Overview</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">{service.fullDescription}</p>
          </div>
        </section>

        {/* Features Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 bg-secondary/30 animate-slide-up animation-delay-200">
          <div className="container mx-auto max-w-4xl">
            <h2 className="text-3xl font-bold mb-8">What We Offer</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {service.features.map((feature, index) => (
                <Card
                  key={index}
                  className="border-border hover:border-primary/50 transition-all duration-300 hover:shadow-md"
                >
                  <CardContent className="flex items-start gap-3 p-4">
                    <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{feature}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 animate-slide-up animation-delay-300">
          <div className="container mx-auto max-w-4xl">
            <h2 className="text-3xl font-bold mb-8">Our Process</h2>
            <div className="space-y-4">
              {service.process.map((step, index) => (
                <Card
                  key={index}
                  className="border-border hover:border-primary/50 transition-all duration-300 hover:shadow-md"
                >
                  <CardHeader className="flex flex-row items-center gap-4 pb-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-primary font-bold">{index + 1}</span>
                    </div>
                    <CardTitle className="text-lg">{step}</CardTitle>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="px-4 sm:px-6 lg:px-8 py-16 bg-gradient-to-br from-primary/10 to-primary/5 animate-slide-up animation-delay-400">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Contact us today for a consultation and let us help you with your legal needs.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 hover:scale-105"
              >
                Schedule Consultation
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-105 bg-transparent"
              >
                Contact Us
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
